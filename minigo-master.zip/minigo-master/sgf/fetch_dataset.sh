#!/bin/bash

wget https://badukmovies.com/pro_games/download -O baduk.zip # games are public domain
unzip baduk.zip -d baduk_db
